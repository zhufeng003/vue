<template>
	<div>
		<h1 class="title">你好啊</h1>
		<School/>
		<Student/>
	</div>
</template>

<script>
	// 脚手架首先扫描的位置，以下顺序会影响相同样式的先后顺序，先引入的优先
	import Student from './components/Student'
	import School from './components/School'

	export default {
		name:'App',
		components:{School,Student}
	}
</script>

<!-- 若未声明scoped、则影响该app.vue组件的所有子组件中title属性 -->
<style scoped>
	.title{
		color: red;
	}
</style>
