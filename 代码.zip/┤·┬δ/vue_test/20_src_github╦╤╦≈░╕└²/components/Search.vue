<template>
	<section class="jumbotron">
		<h3 class="jumbotron-heading">Search Github Users</h3>
		<div>
			<input type="text" placeholder="enter the name you search" v-model="keyWord"/>&nbsp;
			<button @click="searchUsers">Search</button>
		</div>
	</section>
</template>

<script>
	import axios from 'axios'
	export default {
		name:'Search',
		data() {
			return {
				keyWord:''
			}
		},
		methods: {
			searchUsers(){
				// 请求前更新List的数据，触发updateListData事件。回调函数的参数会转化为dataObj，传递参数不考虑先后顺序
				this.$bus.$emit('updateListData', {isLoading:true, errMsg:'', users:[], isFirst:false})
				axios.get(`https://api.github.com/search/users?q=${this.keyWord}`).then(
					response => {
						console.log('请求成功了', response.data)
						// 请求成功后更新List的数据（此时不需要再设置isFirst:false）
						this.$bus.$emit('updateListData', {isLoading:false, errMsg:'', users:response.data.items})
					},
					error => {
						// 请求失败后更新List的数据：此时必须要清空先前的用户数据：users:[]
						console.log('请求失败了', error.message)
						this.$bus.$emit('updateListData', {isLoading:false, errMsg:error.message, users:[]})
					}
				)
			}
		},
	}
</script>
