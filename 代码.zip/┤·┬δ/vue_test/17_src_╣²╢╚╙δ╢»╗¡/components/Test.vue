<!-- 动画效果 -->
<template>
	<div>
		<button @click="isShow = !isShow">显示/隐藏</button>

		<!-- transition：过渡的意思，不会被浏览器解析。VUE会在合适的时候给标签加上come、go的动画效果。
			 appear表示进入页面就有一个远方而来的播放效果。与:appear="true"功能一致 -->
		<transition name="hello" appear>
			<h1 v-show="isShow">你好啊！</h1>
		</transition>
	</div>
</template>

<script>
	export default {
		name:'Test',
		data() {
			return {
				isShow:true
			}
		},
	}
</script>

<!-- VUE不跟动画（atguigu）进行对话，而跟样式的类名（.hello-enter-active）进行对话 -->
<style scoped>
	/* 背景色 */
	h1{
		background-color: orange;
	}

	/* hello为过渡名称，来的时候播放动画。linear表示匀速。默认名称为.v-enter-active */
	.hello-enter-active{
		animation: atguigu 0.5s linear;
	}

	/* 离开的时候播放动画。linear表示匀速，reverse表示反转，默认名称为.v-leave-active */
	.hello-leave-active{
		animation: atguigu 0.5s linear reverse;
	}

	/* 定义动画：名称为atguigu */
	@keyframes atguigu {
		from{
			/* 从远方而来。-100%把所有元素退出去 */
			transform: translateX(-100%);
		}
		to{
			transform: translateX(0px);
		}
	}
</style>