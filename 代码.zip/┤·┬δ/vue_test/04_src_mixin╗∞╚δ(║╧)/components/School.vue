<template>
	<div>
		<h2 @click="showName">学校名称：{{name}}</h2>
		<h2>学校地址：{{address}}</h2>
	</div>
</template>

<script>
	// 引入一个hunhe
	// import {hunhe,hunhe2} from '../mixin'

	// 1、混合中的属性、方法与vm中的属性、方法重叠时，以vm的数据为准
	// 2、针对生命周期钩子，都会输出，且混合中的数据输出在前，vm中的数据输出在后
	export default {
		name:'School',
		data() {
			return {
				name:'尚硅谷',
				address:'北京',
				x:666
			}
		},
		// 局部混合配置
		// mixins:[hunhe,hunhe2],
	}
</script>