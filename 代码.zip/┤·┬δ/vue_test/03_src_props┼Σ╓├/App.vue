<template>
	<div>
		<!-- 组件标签的标签属性，传递数据。 其中:age中的意思是将""中的数据当成表达式，而不是简单字符串-->
		<Student name="李四" sex="女" :age="18"/>
	</div>
</template>

<script>
	// 引入组件 
	import Student from './components/Student'

	export default {
		name:'App',
		// 注册组件
		components:{Student}
	}
</script>
