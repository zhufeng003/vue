<!-- 1、组件的结构。其中template标签不参与结构编译 -->
<template>
	<div class="demo">
		<h2>学校名称：{{name}}</h2>
		<h2>学校地址：{{address}}</h2>
		<button @click="showName">点我提示学校名</button>	
	</div>
</template>

<!-- 2、组件交互相关的代码（数据、方法等等） -->
<script>
	// ES6模块化，暴露模块，其他位置才能引用该组件
	// 1、分别暴露：export const school = Vue.extend({})
	// 2、统一暴露：const school = Vue.extend({})	export {school}
	// 3、默认暴露：const school = Vue.extend({})	export default school  
	//		   同：export default Vue.extend({})	
	//		   同：export default{}  直接暴露组件的配置对象
	export default {
		// 设置组件的名称，最好与文件名保持一致
		name:'School',
		data(){
			return {
				name:'尚硅谷',
				address:'北京昌平'
			}
		},
		methods: {
			showName(){
				alert(this.name)
			}
		},
	}
</script>

<!-- 3、组件的样式 -->
<style>
	.demo{
		background-color: orange;
	}
</style>