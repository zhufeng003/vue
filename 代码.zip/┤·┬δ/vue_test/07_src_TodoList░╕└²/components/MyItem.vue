<template>
	<li>
		<label>
			<!-- 勾选绑定改变事件 -->
			<input type="checkbox" :checked="todo.done" @change="handleCheck(todo.id)"/>

			<!-- 勾选绑定点击事件 -->
			<!-- <input type="checkbox" :checked="todo.done" @click="handleCheck(todo.id)"/> -->
			
			<!-- 如下代码也能实现功能（checkbox、值为布尔），但是不太推荐，因为有点违反原则，因为修改了props，只不过vue没有监测到
			    （vue能监测props对象的变化（地址值），但不能监测props对象属性的变化） -->
			<!-- <input type="checkbox" v-model="todo.done"/> -->
			<span>{{todo.title}}</span>
		</label>
		<!-- 删除按钮绑定点击事件 -->
		<button class="btn btn-danger" @click="handleDelete(todo.id)">删除</button>
	</li>
</template>

<script>
	export default {
		name:'MyItem',
		// 接收MyList组件传递过来的todo、checkTodo、deleteTodo
		props:['todo','checkTodo','deleteTodo'],
		methods: {
			//勾选or取消勾选
			handleCheck(id){
				// 通知App组件将对应的todo对象的done值取反
				this.checkTodo(id)
			},
			//删除
			handleDelete(id){
				// confirm会根据用户的交互来判断值为true、false
				if(confirm('确定删除吗？')){
					//通知App组件将对应的todo对象删除
					this.deleteTodo(id)
				}
			}
		},
	}
</script>

<style scoped>
	/*item*/
	li {
		list-style: none;
		height: 36px;
		line-height: 36px;
		padding: 0 5px;
		border-bottom: 1px solid #ddd;
	}

	li label {
		float: left;
		cursor: pointer;
	}

	li label li input {
		vertical-align: middle;
		margin-right: 6px;
		position: relative;
		top: -1px;
	}

	li button {
		float: right;
		/* 控制按钮隐藏 */
		display: none;
		margin-top: 3px;
	}

	li:before {
		content: initial;
	}

	li:last-child {
		border-bottom: none;
	}
	/* 鼠标悬浮效果：半灰色 */
	li:hover{
		background-color: #ddd;
	}
	
	/* 鼠标悬浮时，显示按钮 */
	li:hover button{
		display: block;
	}
</style>