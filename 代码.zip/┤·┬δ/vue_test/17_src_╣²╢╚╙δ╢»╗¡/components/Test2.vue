<!-- 过渡效果 -->
<template>
	<div>
		<button @click="isShow = !isShow">显示/隐藏</button>

		<!-- transition-group内可以使用多个元素，但每个元素需要匹配唯一key -->
		<transition-group name="hello" appear>
			<h1 v-show="!isShow" key="1">你好啊！</h1>
			<h1 v-show="isShow" key="2">尚硅谷！</h1>
		</transition-group>

		<transition name="hello" appear>
			<div v-show="isShow">
				<h1>你好啊！</h1>
				<h1>尚硅谷！</h1>
			</div>
		</transition>
	</div>
</template>

<script>
	export default {
		name:'Test',
		data() {
			return {
				isShow:true
			}
		},
	}
</script>

<style scoped>
	h1{
		background-color: orange;
		/* transition: 0.5s linear; */
	}

	/* 进入的起点、离开的终点 */
	.hello-enter, .hello-leave-to{
		transform: translateX(-100%);
	}

	/* 元素进入的过程中、元素离开的过程中 */
	.hello-enter-active, .hello-leave-active{
		transition: 0.5s linear;
	}

	/* 进入的终点、离开的起点 */
	.hello-enter-to, .hello-leave{
		transform: translateX(0);
	}
</style>