<template>
	<!-- 第三步：使用组件 -->
	<div>
		<School></School>
		<Student></Student>
	</div>
</template>

<script>
	// 第一步：引入组件。ES6模块化引入
	import School from './School.vue'
	import Student from './Student.vue'

	export default {
		name:'App',
		// 第二步：注册组件
		components:{
			School,
			Student
		}
	}
</script>
