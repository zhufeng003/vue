<template>
	<div class="app">
		<h1>{{msg}}，学生姓名是:{{studentName}}</h1>

		<!-- 通过父组件给子组件传递函数类型的props实现：子给父传递数据 -->
		<School :getSchoolName="getSchoolName"/>

		<!-- v-on:atguigu，给Student组件绑定了一个事件。v-on是在Student组件标签上，
			 所以给Student组件的实例对象vc上绑定了一个事件，事件的名称为atguigu。其他触发了该事件，就会触发demo函数 -->
		<Student v-on:atguigu="getStudentName"/>

		<!-- 通过父组件给子组件绑定一个自定义事件实现：子给父传递数据（第一种写法，使用@或v-on） -->
		<!-- <Student @atguigu="getStudentName" v-on:demo="m1"/> -->

		<!-- 通过父组件给子组件绑定一个自定义事件实现：子给父传递数据（第二种写法，使用ref），与mounted()配合使用 -->
		<!-- 组件够绑定原生的DOM事件，比如@click，但都需要结合.native使用，不然组件会把click当作自定义事件处理
			 此处原生@click事件会作用到Student组件的div标签 -->
		<Student ref="student" @click.native="show"/>
	</div>
</template>

<script>
	import Student from './components/Student'
	import School from './components/School'

	export default {
		name:'App',
		components:{School,Student},
		data() {
			return {
				msg:'你好啊！',
				studentName:''
			}
		},
		methods: {
			// 回调函数
			getSchoolName(name){
				console.log('App收到了学校名: ', name)
			},
			// params为数组
			getStudentName(name,...params){
				console.log('App收到了学生名: ', name, params)
				this.studentName = name
			},
			m1(){
				console.log('demo事件被触发了!!!')
			},
			show(){
				alert(123)
			}
		},
		// 挂载完毕（App.vue）
		mounted() {
			// 给student实例绑定atguigu自定义事件，事件的回调函数为this.getStudentName（在父组件中）
			this.$refs.student.$on('atguigu', this.getStudentName) 	//绑定自定义事件，事件名称：atguigu，绑定对象：student

			// this.$refs.student.$once('atguigu',this.getStudentName) //绑定自定义事件（一次性）

			// setTimeout(()=>{
			// 	this.$refs.student.$on('atguigu', this.getStudentName)
			// }, 3000)
		},
	}
</script>

<style scoped>
	.app{
		background-color: gray;
		padding: 5px;
	}
</style>
