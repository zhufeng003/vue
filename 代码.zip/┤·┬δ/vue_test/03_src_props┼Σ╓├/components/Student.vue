<template>
	<div>
		<h1>{{msg}}</h1>
		<h2>学生姓名：{{name}}</h2>
		<h2>学生性别：{{sex}}</h2>
		<h2>学生年龄：{{myAge+1}}</h2>
		<button @click="updateAge">尝试修改收到的年龄</button>
	</div>
</template>

<script>
	export default {
		name:'Student',
		data() {
			console.log(this)	// this表示组件实例对象VueComponent
			return {
				// 若出现传递过来的属性与vc属性名相同，前者优先级更高
				msg:'我是一个尚硅谷的学生',
				// 传递过来的属性再赋值给vc的属性，props比data的优先级更高
				myAge:this.age
			}
		},
		methods: {
			updateAge(){
				this.myAge++
				// 不能直接操作props中的属性
				// this.age = 99,
			}
		},
		// 简单声明接收App.vue传递过来的数据：<Student name="李四" sex="女" age="18"/>
		// 若声明了没有传递过来的属性，则该属性的最终值为undefined，比如：props:['name','age','sex','phone'] 
		// props:['name','age','sex'] 

		// 接收的同时对数据进行类型限制。props：属性
		/* props:{
			name:String,
			age:Number,
			sex:String
		} */

		// 接收的同时对数据进行：类型限制 + 默认值的指定 + 必要性的限制  
		props:{
			name:{
				type:String, 		// name的类型是字符串
				required:true, 		// name是必要的
			},
			age:{
				type:Number,
				default:99 			//默认值
			},
			sex:{
				type:String,
				required:true
			}
		}
	}
</script>