// 脚手架会扫描整个main.js文件的import语句，然后把所有的import语句按照编写代码的顺序全部汇总到最上方，
// 即最新执行所有import语句（无论import语句前是否有其他语句）

//引入Vue
import Vue from 'vue'
//引入App
import App from './App.vue'
//引入插件
import vueResource from 'vue-resource'
// import Vuex from 'vuex'

//引入store，默认引入store目录下的index.js文件（若不存，则会报错），完整写法：import store from './store/index'
//此时会创建store对象，此创建之前需要先应用Vuex实例（这个动作必须放到store/index中）
import store from './store'

//关闭Vue的生产提示
Vue.config.productionTip = false

//使用插件
Vue.use(vueResource)
// Vue.use(Vuex)

//创建vm
new Vue({
	el:'#app',
	render: h => h(App),
	// 给所有vm、vc配置store对象
	store,	// 完整写法为store:store
	beforeCreate() {
		Vue.prototype.$bus = this
	}
})
