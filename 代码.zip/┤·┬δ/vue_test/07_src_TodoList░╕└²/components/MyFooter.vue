<template>
	<!-- v-show="total"：total为0时不展示 -->
	<div class="todo-footer" v-show="total">
		<label>
			<!-- <input type="checkbox" :checked="isAll" @change="checkAll"/> -->

			<!-- 输入类型的节点，输入的初始值要展示、后期还要有交互，此时可以将这两者合并，使用v-model
				此时isAll会有更新操作，所以计算属性需要有setter、不能使用简写方式 
				此时v-model绑定的是计算属性isAll，可以对其进行修改操作。若绑定的是props，则不建议使用v-model进行修改操作
			-->
			<input type="checkbox" v-model="isAll"/>
		</label>
		<span>
			<span>已完成{{doneTotal}}</span> / 全部{{total}}
		</span>
		<button class="btn btn-danger" @click="clearAll">清除已完成任务</button>
	</div>
</template>

<script>
	export default {
		name:'MyFooter',
		props:['todos','checkAllTodo','clearAllTodo'],
		// 计算属性
		computed: {
			// 总数
			total(){
				return this.todos.length
			},
			// 已完成数
			doneTotal(){

				// 方式一：
				// let i = 0
				// this.todos.forEach((todo) => {
				// 	if(todo.done) i++
				// });
				// return i

				// 方式二：此处使用reduce方法做条件统计。会调用数组长度为次数，pre：上一次的返回值，current当前的元素
				/* const x = this.todos.reduce((pre,current)=>{
					console.log('@',pre,current)
					return pre + (current.done ? 1 : 0)
				},0) */
				// 简写
				return this.todos.reduce((pre,todo)=> pre + (todo.done ? 1 : 0) ,0)
			},
			// 控制全选框。通过其他两个计算属性计算而得
			isAll:{
				//全选框是否勾选
				get(){
					return this.doneTotal === this.total && this.total > 0
				},
				//isAll被修改时set被调用，value表示是否被勾选、值为true或false
				set(value){
					this.checkAllTodo(value)
				}
			}
		},
		methods: {
			/* checkAll(e){
				this.checkAllTodo(e.target.checked)
			} */
			//清空所有已完成
			clearAll(){
				this.clearAllTodo()
			}
		},
	}
</script>

<style scoped>
	/*footer*/
	.todo-footer {
		height: 40px;
		line-height: 40px;
		padding-left: 6px;
		margin-top: 5px;
	}

	.todo-footer label {
		display: inline-block;
		margin-right: 20px;
		cursor: pointer;
	}

	.todo-footer label input {
		position: relative;
		top: -1px;
		vertical-align: middle;
		margin-right: 5px;
	}

	.todo-footer button {
		float: right;
		margin-top: 5px;
	}
</style>