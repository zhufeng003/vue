//引入Vue
import Vue from 'vue'
//引入App
import App from './App.vue'

//引入插件库
import vueResource from 'vue-resource'

//关闭Vue的生产提示
Vue.config.productionTip = false

//使用插件，此后所有vc和vm都会带有$http属性，可使用this直接调用$http
Vue.use(vueResource)

//创建vm
new Vue({
	el:'#app',
	render: h => h(App),
	beforeCreate() {
		Vue.prototype.$bus = this
	},
})