//该文件用于创建Vuex中最为核心的store。见到store就如同见到了Vuex

//引入vue
import Vue from 'vue'

//引入Vuex
import Vuex from 'vuex'
//应用Vuex插件。需要先使用Vuex实例，才能创建store对象。
//所以不能放到main.js文件中应用Vuex插件，那样不能控制应用Vuex插件与创建store对象的先后顺序
Vue.use(Vuex)


// 准备actions：用于响应组件中的动作，actions就是一个object对象。主要写业务逻辑。actions中所有的方法名均为小写
const actions = {

	// jia(context,value){
	// 	console.log('actions中的jia被调用了')
	// 	context.commit('JIA',value)
	// },
	// jian(context,value){
	// 	console.log('actions中的jian被调用了')
	// 	context.commit('JIAN',value)
	// }, 

	// context：store的上下文，里面包含部分store的属性，比如commit、dispatch、state
	// value表示传递过来的数据
	jiaOdd(context,value){
		console.log('actions中的jiaOdd被调用了', context)
		console.log('处理了一些事情 -- jiaOdd')
		context.dispatch('demo1', value)
	},
	demo1(context,value){
		console.log('处理了一些事情 -- demo1')
		context.dispatch('demo2', value)
	},
	demo2(context,value){
		console.log('处理了一些事情 -- demo2')
		if(context.state.sum % 2){
			// 转发
			context.commit('JIA',value)
		}
	},

	jiaWait(context,value){
		console.log('actions中的jiaWait被调用了')
		setTimeout(()=>{
			context.commit('JIA',value)
			// context.state.sum += value，可实现功能，但此时开发者工具（只能监测mutations）监测不到，不推荐使用
		},500)
	}
}

// 准备mutations：用于操作数据（state），mutations中所有的方法名均为大写
const mutations = {
	// 监测数据的变化，state为对象（含get、set方法）
	JIA(state, value){
		console.log('mutations中的JIA被调用了')
		state.sum += value
	},
	JIAN(state,value){
		console.log('mutations中的JIAN被调用了')
		state.sum -= value
	}
}

// 准备state：用于存储数据
const state = {
	sum:0 		// 当前的和
}

// 创建并暴露（导出）store，store的作用是管理actions、mutations、state
export default new Vuex.Store({
	// 若对象内的key与保存对应值的变量重名，会触发对象的简写形式
	actions:actions,
	mutations,
	state,
})