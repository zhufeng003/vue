<template>
	<div class="category">
		<h3>{{title}}分类</h3>
		<!-- 将games数据绑定到games属性上，并通过slot传递给插槽的使用者App组件
		     数据的使用者（插槽的使用者）只决定数据结构的展示，数据由插槽定义的组件提供 -->
		<slot :games="games" msg="hello">我是默认的一些内容</slot>
	</div>
</template>

<script>
	export default {
		name:'Category',
		props:['title'],
		// 数据在子组件自身
		data() {
			return {
				games:['红色警戒','穿越火线','劲舞团','超级玛丽'],
			}
		},
	}
</script>

<style scoped>
	.category{
		background-color: skyblue;
		width: 200px;
		height: 300px;
	}
	h3{
		text-align: center;
		background-color: orange;
	}
	video{
		width: 100%;
	}
	img{
		width: 100%;
	}
</style>