// 该文件专门用于创建整个应用的路由器
import VueRouter from 'vue-router'
//引入组件
import About from '../components/About'
import Home from '../components/Home'

//创建并暴露一个路由器，管理一堆路由，监测路径的变化，展示不同的组件
export default new VueRouter({
	routes:[
		{
			path:'/about',		// 路径
			component:About		// 映射的组件
		},
		{
			path:'/home',
			component:Home
		}
	]
})
