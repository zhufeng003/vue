<template>
	<div class="school">
		<h2>学校名称：{{name}}</h2>
		<h2>学校地址：{{address}}</h2>
	</div>
</template>

<script>
	// 引入pubsub-js，pubsub为一个对象
	import pubsub from 'pubsub-js'
	export default {
		name:'School',
		data() {
			return {
				name:'尚硅谷',
				address:'北京',
			}
		},
		mounted() {
			// 给原型对象$bus（媒介）绑定一个名为hello的事件，若有人触发了hello事件，则执行回调函数
			// this.$bus.$on('hello',(data)=>{
			// 	console.log('我是School组件，收到了数据',data)
			// }) 

			// 订阅消息：消息名为hello，若有人发布了名为hello的消息，则执行回调函数（消息名, 数据），返回值为订阅Id
			this.pubId = pubsub.subscribe('hello', (msgName,data)=>{
				// console.log(this)
				console.log('有人发布了hello消息，hello消息的回调执行了', msgName, data)
			})
		},
		beforeDestroy() {
			// 在该组件销毁之前，解绑$bus（媒介）与事件hello之间的关联
			// this.$bus.$off('hello')

			// 取消订阅
			pubsub.unsubscribe(this.pubId)
		},
	}
</script>

<style scoped>
	.school{
		background-color: skyblue;
		padding: 5px;
	}
</style>