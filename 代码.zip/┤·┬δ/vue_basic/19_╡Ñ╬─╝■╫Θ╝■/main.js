// 入口文件

import App from './App.vue'

// 创建Vue实例
new Vue({
	// 指定服务的容器
	el:'#root',
	// 与在容器中写入<App></App>效果一致
	template:`<App></App>`,
	// 注册组件
	components:{
		App
	},
})