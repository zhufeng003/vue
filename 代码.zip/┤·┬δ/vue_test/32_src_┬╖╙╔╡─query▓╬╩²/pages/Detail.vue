<template>
	<ul>
		<li>消息编号：{{$route.query.id}}</li>
		<li>消息标题：{{$route.query.title}}</li>
	</ul>
</template>

<script>
	export default {
		name:'Detail',
		mounted() {
			// this.$route：获取该组件相关的路由信息，包含query、path、params、fullPath等属性
			console.log(this.$route)
		},
	}
</script>