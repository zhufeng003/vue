<template>
	<div class="container">
		<!-- 给Category组件传递属性title，若传递变量，使用单向数据绑定，比如：:listData="foods" -->
		<Category title="美食" >
			<!-- img标签是在当前组件完成解析之后，填充到Category组件，所以img标签的样式可以写在当前组件中，也可以写到Category组件中 -->
			<!-- Category组件使用slot接收img标签 -->
			<img src="https://s3.ax1x.com/2021/01/16/srJlq0.jpg" alt="">
		</Category>

		<Category title="游戏" >
			<ul>
				<li v-for="(g,index) in games" :key="index">{{g}}</li>
			</ul>
		</Category>

		<Category title="电影">
			<!-- controls显示视频播放按钮 -->
			<video controls src="http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4"></video>
		</Category>
	</div>
</template>

<script>
	import Category from './components/Category'
	export default {
		name:'App',
		components:{Category},
		data() {
			return {
				foods:['火锅','烧烤','小龙虾','牛排'],
				games:['红色警戒','穿越火线','劲舞团','超级玛丽'],
				films:['《教父》','《拆弹专家》','《你好，李焕英》','《尚硅谷》']
			}
		},
	}
</script>

<style scoped>
	.container{
		/* 弹性盒模型 */
		display: flex;

		/* 主轴对齐方式 */
		justify-content: space-around;
	}
</style>
