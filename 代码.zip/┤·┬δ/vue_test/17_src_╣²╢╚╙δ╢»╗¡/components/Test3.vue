<!-- 集成第三方动画 -->
<template>
	<div>
		<button @click="isShow = !isShow">显示/隐藏</button>

		<!-- name="animate__animated animate__bounce"：第三方库的默认配置
			 enter-active-class：进入的动画
			 leave-active-class：离开的动画 -->
		<transition-group 
			appear
			name="animate__animated animate__bounce" 
			enter-active-class="animate__swing"
			leave-active-class="animate__backOutUp"
		>
			<h1 v-show="!isShow" key="1">你好啊！</h1>
			<h1 v-show="isShow" key="2">尚硅谷！</h1>
		</transition-group>
	</div>
</template>

<script>
	// 引入第三方动画库。地址：animate.style。引入样式不需要import XX from XXX
	import 'animate.css'
	export default {
		name:'Test',
		data() {
			return {
				isShow:true
			}
		},
	}
</script>

<style scoped>
	h1{
		background-color: orange;
	}
</style>