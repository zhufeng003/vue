<template>
	<div class="school">
		<h2>学校名称：{{name}}</h2>
		<h2>学校地址：{{address}}</h2>
	</div>
</template>

<script>
	export default {
		name:'School',
		data() {
			return {
				name:'尚硅谷',
				address:'北京',
			}
		},
		mounted() {
			// console.log('School',this)

			// 方式一：给原型对象x（媒介）绑定一个名为hello的事件，若有人触发了hello事件，则执行回调函数
			// this.x.$on('hello',(data)=>{
			// 	console.log('我是School组件, 收到了数据', data)
			// })

			// 方式二：全局事件总线（与方式一的使用完成一致）
			this.$bus.$on('hello',(data)=>{
				console.log('我是School组件，收到了数据', data)
			})
		},
		beforeDestroy() {
			// 在该组件销毁之前，解绑$bus（媒介）与事件hello之间的关联
			this.$bus.$off('hello')
		},
	}
</script>

<style scoped>
	.school{
		background-color: skyblue;
		padding: 5px;
	}
</style>