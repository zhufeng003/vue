<template>
	<div class="container">

		<!-- App组件是Category组件的使用者 -->
		<!-- 插槽的作用就是插槽的使用者给插槽里面填充结构（数据） -->
		<Category title="游戏">

			<!-- 填充的结构必须被template标签包裹，使用scope接收定义插槽时传递过来的数据，atguigu接收到的是传递过来的games对象
				 atguigu中包含传递过来的所有对象 -->
			<template scope="atguigu">
				<!-- 无序列表 -->
				<ul>
					<li v-for="(g,index) in atguigu.games" :key="index">{{g}}</li>
				</ul>
				<h4>{{atguigu.msg}}}</h4>
			</template>
		</Category>

		<Category title="游戏">
			<!-- {games}：ES6语法结构赋值 -->
			<template scope="{games}">
				<!-- 有序列表 -->
				<ol>
					<li style="color:red" v-for="(g,index) in games" :key="index">{{g}}</li>
				</ol>
			</template>
		</Category>

		<Category title="游戏">
			<template slot-scope="{games}">
				<h4 v-for="(g,index) in games" :key="index">{{g}}</h4>
			</template>
		</Category>

	</div>
</template>

<script>
	import Category from './components/Category'
	export default {
		name:'App',
		components:{Category},
	}
</script>

<style scoped>
	.container,.foot{
		display: flex;
		justify-content: space-around;
	}
	h4{
		text-align: center;
	}
</style>
