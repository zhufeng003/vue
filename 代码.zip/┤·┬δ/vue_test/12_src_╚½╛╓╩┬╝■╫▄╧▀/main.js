//引入Vue
import Vue from 'vue'
//引入App
import App from './App.vue'
//关闭Vue的生产提示
Vue.config.productionTip = false


// 方式一：
// 创建VC实例对象
const Demo = Vue.extend({})
const d = new Demo()

// 给Vue创建原型对象x，并赋值对象d。把x当做传递数据的媒介
Vue.prototype.x = d


//创建vm
new Vue({
	el:'#app',
	render: h => h(App),
	// 方式二：全局事件总线
	beforeCreate() {
		// 安装全局事件总线：往Vue原型上存放$bus（媒介），并将当前vm（this）赋值给$bus，此后全局所有的VC和VM都能看到$bus
		// $bus只是个单纯的变量名，加$的原因是迎合vue设计。此处设计为x一个意思
		Vue.prototype.$bus = this 
	},
})