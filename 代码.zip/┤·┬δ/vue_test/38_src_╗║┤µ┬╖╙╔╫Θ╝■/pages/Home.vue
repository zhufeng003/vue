<template>
	<div>
		<h2>Home组件内容</h2>
		<div>
			<ul class="nav nav-tabs">
				<!-- 当前组件被切换后，该路由组件默认是被销毁掉的，再次切换到该组件时，需要重新挂载，生成新的真实DOM替换原有数据 -->
				<li>
					<router-link class="list-group-item" active-class="active" to="/home/news">News</router-link>
				</li>
				<li>
					<router-link class="list-group-item" active-class="active" to="/home/message">Message</router-link>
				</li>
			</ul>
			<!-- 缓存当前组件中所有的路由组件：News、Message -->
			<!-- <keep-alive>
				<router-view></router-view>
			</keep-alive> -->

			<!-- 缓存多个路由组件 -->
			<!-- <keep-alive :include="['News','Message']">
				<router-view></router-view>
			</keep-alive> -->
				
			<!-- 缓存一个路由组件、News为组件名 -->
			<keep-alive include="News">
				<router-view></router-view>
			</keep-alive>
		</div>
	</div>
</template>

<script>
	export default {
		name:'Home',
		// beforeDestroy() {
		// 	console.log('Home组件即将被销毁了')
		// }, 
		/* mounted() {
			console.log('Home组件挂载完毕了',this)
			window.homeRoute = this.$route
			window.homeRouter = this.$router
		},  */
	}
</script>